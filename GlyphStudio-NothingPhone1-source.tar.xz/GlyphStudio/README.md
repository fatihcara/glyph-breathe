# Glyph Studio — Nothing Phone (1)

A rooted Android app project for controlling the Nothing Phone (1) Glyph interface through the AW210xx sysfs node. It is designed for the Phone (1), not Phone (2), Phone (2a), or other Nothing models.

## What is included

- **Paint canvas:** tap or drag across a visual Phone (1) Glyph layout to light assigned zones.
- **Tap toggle:** tap a zone to switch it on/off.
- **Erase:** tap/drag to turn mapped zones off.
- **Raw channel panel:** direct control of hardware indices 0–33, with per-channel brightness and an automatic scan.
- **Mapping wizard:** lights one raw index at a time; tap the matching logical zone or choose it from the list. Several raw indices may map to one logical zone.
- **Effects:** Breathe, Chase, Wave and Pulse, running only while the app is in the foreground.
- **Snapshot:** save/load the current 15-zone brightness pattern.
- **Safety cleanup:** the app sends zero brightness to the raw indices when it leaves the foreground or is destroyed normally.

## Hardware interface

The app writes to:

`/sys/class/leds/aw210xx_led/single_led_br`

The write format is:

`<raw-index> <brightness>`

For example, `10 300` means raw index 10 at brightness 300. The app does **not** read `single_led_br`; on some kernels it is write-only and reading it returns `I/O error`. Maximum brightness is read from:

`/sys/class/leds/aw210xx_led/max_brightness`

Your phone reported `4095`.

The raw index range 0–33 is based on the public Phone (1) sysfs test program. It is a scan range, not a guarantee that every index is active on every kernel. During calibration, skip indices that do not light a visible Glyph. This does not mean the app can address each of the phone's hundreds of individual diffuser LEDs separately; the app controls the driver's addressable outputs and the SDK's logical zones.

Nothing's public Glyph Developer Kit documents 15 logical zones for Phone (1): A1, B1, C1–C4, D1_1–D1_8, and E1. These logical zone identifiers are **not assumed** to be the same as the raw AW210xx indices. The calibration wizard creates that mapping on your exact ROM/kernel.

## Requirements

- Nothing Phone (1) (`20111` hardware)
- Root access through Magisk, Kitsune, KernelSU, or a compatible `su` implementation
- The AW210xx sysfs directory and `single_led_br` node exposed by the kernel
- Android 8.0 / API 26 or newer

## Build in Android Studio

1. Extract the ZIP and open the `GlyphStudio` folder in Android Studio.
2. Allow Gradle sync. The project uses Android Gradle Plugin 8.9.1, Kotlin 2.1.10, Gradle 8.11.1, and JDK 17.
3. Build **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Install the generated debug APK on the Nothing Phone (1).
5. Open Glyph Studio and approve its root request in Magisk/Kitsune.

The project uses only Android framework UI APIs; it has no third-party runtime libraries and requests no network permissions. The included small, readable bootstrap JAR/source downloads Gradle 8.11.1 from the official Gradle distribution URL if it is not already installed (internet is required for the first build).

## First run

1. Open **CHANNELS** and tap **SCAN 0–33**. Watch the back of the phone and note which raw indices light a physical segment. Stop or let the scan finish.
2. Open **MAP** and press **START**. When a raw output lights, tap its matching zone on the phone diagram. For the small USB-line divisions, use the zone picker and **ASSIGN CHOSEN ZONE TO CURRENT LED**.
3. Press **SKIP** for indices that do not light anything. Press **FINISH** when done.
4. Open **PAINT**. Choose PAINT, TAP TOGGLE, or ERASE, then tap or draw on the Glyph diagram.
5. Use **FX** for live animation presets.

The mapping is saved locally in app preferences and survives app restarts. You can clear and recalibrate it at any time.

## Important limitations

- The visual diagram is a touch target/editor for the documented logical zones. The exact mapping is established by your calibration; the app does not guess raw-index-to-zone relationships.
- The app controls Glyph lights while it is open. It does **not** implement an always-listening, screen-off gesture or wake the phone display. Background gesture detection would require a separate privileged service and careful battery/privacy design.
- Animations stop and the app attempts to clear the LEDs when it goes into the background. A force-stop, kernel crash, or sudden power loss can prevent cleanup; if LEDs remain lit, reopen the app and press **ALL OFF** in CHANNELS.
- This is an initial source release. It has not been compiled against your exact Evolution X build or physically validated on your handset. The raw-index scan and calibration step are deliberately included for that reason.

## Source references

- Nothing Developer Programme, Glyph Developer Kit (Phone 1 logical zone indices): https://github.com/Nothing-Developer-Programme/Glyph-Developer-Kit
- Moe-sushi, `nothing-glyph-test` (Phone 1 AW210xx sysfs node and write format): https://github.com/Moe-sushi/nothing-glyph-test


## Automated debug build

The parent repository includes a GitHub Actions workflow named **Build Glyph Studio Debug APK**. Every push to `main` that changes this project starts a build. A successful run verifies the APK signature and application ID, then publishes an artifact named `GlyphStudio-debug-apk` for 14 days.

A CI build verifies compilation, packaging, and debug signing only. It does not validate the raw-index mapping or test LED behaviour on a physical Phone (1). The first on-device run still requires root approval and calibration.
