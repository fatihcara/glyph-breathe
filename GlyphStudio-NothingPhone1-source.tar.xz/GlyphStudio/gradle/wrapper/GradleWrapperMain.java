package org.gradle.wrapper;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.PosixFilePermission;
import java.util.EnumSet;
import java.util.Properties;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Minimal transparent Gradle bootstrapper used because this project is packaged without
 * the proprietary/generated Gradle wrapper JAR. It downloads the pinned official Gradle
 * distribution over HTTPS, extracts it under ~/.gradle, then starts that Gradle executable.
 */
public final class GradleWrapperMain {
    private GradleWrapperMain() {}

    public static void main(String[] args) throws Exception {
        Path project = Paths.get("").toAbsolutePath().normalize();
        Path propertiesFile = project.resolve("gradle/wrapper/gradle-wrapper.properties");
        Properties properties = new Properties();
        try (InputStream in = Files.newInputStream(propertiesFile)) {
            properties.load(in);
        }
        String distributionUrl = properties.getProperty("distributionUrl");
        if (distributionUrl == null || !distributionUrl.startsWith("https://")) {
            throw new IllegalStateException("A valid HTTPS distributionUrl is required in gradle-wrapper.properties");
        }
        String fileName = distributionUrl.substring(distributionUrl.lastIndexOf('/') + 1);
        String distributionName = fileName.replace("-bin.zip", "").replace("-all.zip", "");
        String version = distributionName.startsWith("gradle-") ? distributionName.substring(7) : distributionName;
        Path gradleUserHome = Paths.get(System.getenv().getOrDefault("GRADLE_USER_HOME",
                Paths.get(System.getProperty("user.home"), ".gradle").toString()));
        Path installRoot = gradleUserHome.resolve("wrapper/dists/glyphstudio-" + version);
        Path distributionDir = installRoot.resolve(distributionName);
        Path executable = distributionDir.resolve(isWindows() ? "bin/gradle.bat" : "bin/gradle");

        if (!Files.isRegularFile(executable)) {
            Files.createDirectories(installRoot);
            Path zip = installRoot.resolve(fileName + ".download");
            System.out.println("Downloading Gradle " + version + " from the official Gradle distribution service…");
            download(distributionUrl, zip);
            extract(zip, installRoot);
            Files.deleteIfExists(zip);
        }
        if (!Files.isRegularFile(executable)) {
            throw new IOException("Gradle distribution extracted, but executable was not found: " + executable);
        }
        if (!isWindows()) {
            try {
                Set<PosixFilePermission> perms = EnumSet.of(PosixFilePermission.OWNER_READ,
                        PosixFilePermission.OWNER_WRITE, PosixFilePermission.OWNER_EXECUTE,
                        PosixFilePermission.GROUP_READ, PosixFilePermission.GROUP_EXECUTE,
                        PosixFilePermission.OTHERS_READ, PosixFilePermission.OTHERS_EXECUTE);
                Files.setPosixFilePermissions(executable, perms);
            } catch (UnsupportedOperationException ignored) {}
        }
        java.util.List<String> command = new java.util.ArrayList<>();
        if (isWindows()) {
            command.add("cmd.exe"); command.add("/c");
        }
        command.add(executable.toString());
        for (String arg : args) command.add(arg);
        Process process = new ProcessBuilder(command).directory(project.toFile()).inheritIO().start();
        System.exit(process.waitFor());
    }

    private static void download(String address, Path destination) throws IOException {
        HttpURLConnection connection = (HttpURLConnection) URI.create(address).toURL().openConnection();
        connection.setInstanceFollowRedirects(true);
        connection.setConnectTimeout(15000);
        connection.setReadTimeout(60000);
        connection.setRequestProperty("User-Agent", "GlyphStudio-Gradle-Bootstrap/1.0");
        int status = connection.getResponseCode();
        if (status < 200 || status >= 300) throw new IOException("Gradle download failed with HTTP " + status);
        try (InputStream in = connection.getInputStream(); OutputStream out = Files.newOutputStream(destination)) {
            byte[] buffer = new byte[1024 * 128];
            int count;
            while ((count = in.read(buffer)) >= 0) out.write(buffer, 0, count);
        } finally {
            connection.disconnect();
        }
    }

    private static void extract(Path zip, Path destination) throws IOException {
        Path root = destination.toAbsolutePath().normalize();
        try (ZipInputStream in = new ZipInputStream(Files.newInputStream(zip))) {
            ZipEntry entry;
            byte[] buffer = new byte[1024 * 64];
            while ((entry = in.getNextEntry()) != null) {
                Path target = root.resolve(entry.getName()).normalize();
                if (!target.startsWith(root)) throw new IOException("Unsafe path in Gradle archive");
                if (entry.isDirectory()) {
                    Files.createDirectories(target);
                } else {
                    Files.createDirectories(target.getParent());
                    try (OutputStream out = Files.newOutputStream(target)) {
                        int count;
                        while ((count = in.read(buffer)) >= 0) out.write(buffer, 0, count);
                    }
                }
                in.closeEntry();
            }
        }
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase().contains("win");
    }
}
