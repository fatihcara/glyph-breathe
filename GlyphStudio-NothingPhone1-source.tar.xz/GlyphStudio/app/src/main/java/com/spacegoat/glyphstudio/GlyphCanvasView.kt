package com.spacegoat.glyphstudio

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.min
import kotlin.math.sqrt

class GlyphCanvasView(context: Context) : View(context) {
    var onZoneTouched: ((Int) -> Unit)? = null
    var selectedZone: Int = -1
        set(value) { field = value; invalidate() }
    var zoneLevels: IntArray = IntArray(15)
        set(value) { field = value.copyOf(); invalidate() }
    var mappedZones: Set<Int> = emptySet()
        set(value) { field = value; invalidate() }
    var selectionOnly: Boolean = false
    private var lastTouchedZone: Int = -1

    private val scaleRect = RectF()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val base = Color.rgb(34, 38, 42)
    private val dim = Color.rgb(82, 89, 94)
    private val white = Color.rgb(236, 242, 244)
    private val accent = Color.rgb(239, 70, 77)
    private val muted = Color.rgb(135, 144, 149)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        contentDescription = "Interactive Nothing Phone 1 Glyph layout. Tap or draw across a Glyph zone."
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val s = min(width / 320f, height / 560f)
        val left = (width - 320f * s) / 2f
        val top = (height - 560f * s) / 2f
        canvas.save()
        canvas.translate(left, top)
        canvas.scale(s, s)
        drawPhone(canvas)
        drawZones(canvas)
        drawLegend(canvas)
        canvas.restore()
    }

    private fun drawPhone(canvas: Canvas) {
        p.color = Color.rgb(17, 20, 23)
        p.style = Paint.Style.FILL
        canvas.drawRoundRect(17f, 10f, 303f, 550f, 28f, 28f, p)
        p.color = Color.rgb(47, 53, 58)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f
        canvas.drawRoundRect(17f, 10f, 303f, 550f, 28f, 28f, p)

        // Subtle camera glass and wireless charging coil guides.
        p.style = Paint.Style.FILL
        p.color = Color.rgb(27, 31, 35)
        canvas.drawRoundRect(54f, 53f, 138f, 151f, 40f, 40f, p)
        canvas.drawCircle(96f, 78f, 16f, p)
        canvas.drawCircle(96f, 126f, 16f, p)
        p.color = Color.rgb(24, 28, 31)
        canvas.drawCircle(150f, 307f, 82f, p)
        p.color = Color.rgb(42, 47, 51)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.5f
        canvas.drawCircle(150f, 307f, 82f, p)
        p.style = Paint.Style.FILL
    }

    private fun drawZones(canvas: Canvas) {
        for (zone in GlyphZones.all) {
            val level = zoneLevels.getOrElse(zone.index) { 0 }
            val isSelected = zone.index == selectedZone
            val isMapped = mappedZones.contains(zone.index)
            val active = level > 0
            val color = when {
                isSelected -> accent
                active -> white
                isMapped -> Color.rgb(125, 145, 151)
                else -> dim
            }
            val width = when (zone.index) {
                0 -> 10f
                1 -> 11f
                in 2..5 -> 10f
                6 -> 11f
                else -> 8f
            }
            if (active || isSelected) {
                glowPaint.color = color
                glowPaint.style = Paint.Style.STROKE
                glowPaint.strokeWidth = width + 7f
                glowPaint.strokeCap = Paint.Cap.ROUND
                glowPaint.strokeJoin = Paint.Join.ROUND
                glowPaint.alpha = if (active) 80 else 45
                glowPaint.setShadowLayer(13f, 0f, 0f, color)
                drawZoneShape(canvas, zone.index, glowPaint)
                glowPaint.clearShadowLayer()
                glowPaint.alpha = 255
            }
            p.color = color
            p.style = Paint.Style.STROKE
            p.strokeWidth = width
            p.strokeCap = Paint.Cap.ROUND
            p.strokeJoin = Paint.Join.ROUND
            drawZoneShape(canvas, zone.index, p)
            p.style = Paint.Style.FILL

            if (isSelected || (!selectionOnly && !isMapped)) {
                p.color = if (isSelected) accent else muted
                p.textSize = 10f
                p.textAlign = Paint.Align.CENTER
                val label = when (zone.index) {
                    in 7..14 -> (zone.index - 6).toString()
                    else -> zone.name
                }
                canvas.drawText(label, zone.x, zone.y + 4f, p)
            }
        }
    }

    private fun drawZoneShape(canvas: Canvas, index: Int, paint: Paint) {
        when (index) {
            0 -> canvas.drawRoundRect(54f, 53f, 138f, 151f, 42f, 42f, paint)
            1 -> {
                val path = Path().apply {
                    moveTo(178f, 91f)
                    cubicTo(247f, 83f, 276f, 130f, 239f, 164f)
                    cubicTo(225f, 177f, 212f, 184f, 199f, 195f)
                }
                canvas.drawPath(path, paint)
            }
            in 2..5 -> {
                val angles = mapOf(2 to 205f, 3 to 295f, 4 to 25f, 5 to 115f)
                canvas.drawArc(RectF(38f, 195f, 262f, 419f), angles[index] ?: 0f, 72f, false, paint)
            }
            in 7..14 -> {
                val y = 480f - (index - 7) * 8f
                canvas.drawRoundRect(145f, y - 3f, 155f, y + 3f, 3f, 3f, paint)
            }
            6 -> canvas.drawCircle(150f, 510f, 8f, paint)
        }
    }

    private fun drawLegend(canvas: Canvas) {
        p.style = Paint.Style.FILL
        p.color = muted
        p.textSize = 10f
        p.textAlign = Paint.Align.LEFT
        canvas.drawText("PHONE (1) · LOGICAL ZONES", 34f, 526f, p)
        p.textAlign = Paint.Align.RIGHT
        canvas.drawText("A1  B1  C1–C4  D1–D8  E1", 286f, 526f, p)
    }

    private fun hitZone(x: Float, y: Float): Int {
        var closest = -1
        var best = Float.MAX_VALUE
        for (zone in GlyphZones.all) {
            val dx = x - zone.x
            val dy = y - zone.y
            val distance = sqrt(dx * dx + dy * dy)
            if (distance <= zone.hitRadius && distance < best) {
                closest = zone.index
                best = distance
            }
        }
        return closest
    }

    private fun notifyTouch(eventX: Float, eventY: Float) {
        val s = min(width / 320f, height / 560f)
        if (s <= 0f) return
        val left = (width - 320f * s) / 2f
        val top = (height - 560f * s) / 2f
        val zone = hitZone((eventX - left) / s, (eventY - top) / s)
        if (zone >= 0 && zone != lastTouchedZone) {
            lastTouchedZone = zone
            selectedZone = zone
            onZoneTouched?.invoke(zone)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastTouchedZone = -1
                notifyTouch(event.x, event.y)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!selectionOnly) notifyTouch(event.x, event.y)
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!selectionOnly) notifyTouch(event.x, event.y)
                performClick()
                lastTouchedZone = -1
                return true
            }
            MotionEvent.ACTION_CANCEL -> return true
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
