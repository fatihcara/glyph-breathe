package com.spacegoat.glyphstudio

data class GlyphZone(
    val index: Int,
    val name: String,
    val group: String,
    val x: Float,
    val y: Float,
    val hitRadius: Float
)

/** Logical Phone (1) zones as indexed by Nothing's public Glyph Developer Kit. */
object GlyphZones {
    val all: List<GlyphZone> = buildList {
        add(GlyphZone(0, "A1", "Camera", 96f, 100f, 43f))
        add(GlyphZone(1, "B1", "Diagonal", 218f, 139f, 38f))
        add(GlyphZone(2, "C1", "Battery", 96f, 210f, 36f))
        add(GlyphZone(3, "C2", "Battery", 247f, 252f, 36f))
        add(GlyphZone(4, "C3", "Battery", 204f, 404f, 36f))
        add(GlyphZone(5, "C4", "Battery", 53f, 362f, 36f))
        add(GlyphZone(6, "E1", "USB dot", 150f, 510f, 19f))
        // Official logical order is D1_1 bottom to D1_8 top.
        for (i in 0 until 8) {
            val sdkIndex = 7 + i
            val y = 480f - i * 8f
            add(GlyphZone(sdkIndex, "D1_${i + 1}", "USB line", 150f, y, 13f))
        }
    }

    val byIndex = all.associateBy { it.index }
}
