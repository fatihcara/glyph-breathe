package com.spacegoat.glyphstudio

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import kotlin.math.sin

class MainActivity : Activity() {
    private enum class Tab { PAINT, CHANNELS, CALIBRATE, EFFECTS }
    private enum class Tool { PAINT, TOGGLE, ERASE }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val root = RootSysfs()
    private val prefs by lazy { getSharedPreferences("glyph_studio", MODE_PRIVATE) }
    private val zoneLevels = IntArray(15)
    private val channelLevels = IntArray(RootSysfs.CHANNEL_COUNT)
    private val hardwareToZone = linkedMapOf<Int, Int>()

    private var currentTab = Tab.PAINT
    private var tool = Tool.PAINT
    private var brushBrightness = 1300
    private var selectedChannel = 0
    private var selectedCalibrationZone = 0
    private var calibrationZoneSpinner: Spinner? = null
    private var scanIndex = -1
    private var calibrationRunning = false
    private var rawScanRunning = false
    private var effectName: String? = null
    private var effectPhase = 0f

    private lateinit var rootLayout: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var brushText: TextView
    private var glyphCanvas: GlyphCanvasView? = null
    private var calibrationCanvas: GlyphCanvasView? = null
    private var channelGrid: LinearLayout? = null
    private var channelTitle: TextView? = null
    private var channelSeekBar: SeekBar? = null
    private var calibrationTitle: TextView? = null
    private var calibrationInfo: TextView? = null

    private val rawScanTick = object : Runnable {
        override fun run() {
            if (!rawScanRunning) return
            val values = (0 until RootSysfs.CHANNEL_COUNT).associateWith { if (it == scanIndex) 800 else 0 }
            root.writeBatch(values)
            channelLevels.fill(0)
            if (scanIndex in channelLevels.indices) channelLevels[scanIndex] = 800
            updateChannelGrid()
            scanIndex++
            if (scanIndex >= RootSysfs.CHANNEL_COUNT) {
                rawScanRunning = false
                scanIndex = -1
                root.allOff()
                updateChannelGrid()
                toast("Raw channel scan complete")
            } else {
                mainHandler.postDelayed(this, 650L)
            }
        }
    }

    private val effectTick = object : Runnable {
        override fun run() {
            val name = effectName ?: return
            val mappedZones = hardwareToZone.values.toSet()
            if (mappedZones.isEmpty()) {
                stopEffect()
                toast("Calibrate the raw channels first")
                return
            }
            val values = IntArray(15)
            val max = root.maxBrightness.coerceAtLeast(1)
            val peak = brushBrightness.coerceIn(1, max)
            when (name) {
                "Breathe" -> {
                    val wave = (0.5 + 0.5 * sin(effectPhase.toDouble())).toFloat()
                    mappedZones.forEach { values[it] = (peak * wave).toInt() }
                }
                "Chase" -> {
                    val active = (effectPhase.toInt() % 15).coerceIn(0, 14)
                    mappedZones.forEach { values[it] = if (it == active) peak else 0 }
                }
                "Wave" -> mappedZones.forEach {
                    val wave = (0.5 + 0.5 * sin(effectPhase.toDouble() + it * 0.55)).toFloat()
                    values[it] = (peak * wave).toInt()
                }
                "Pulse" -> {
                    val on = (effectPhase.toInt() % 2) == 0
                    mappedZones.forEach { values[it] = if (on) peak else 0 }
                }
            }
            zoneLevels.indices.forEach { zoneLevels[it] = values[it] }
            root.writeBatch(buildHardwareFrame(values))
            effectPhase += when (name) {
                "Chase" -> 1f
                "Pulse" -> 1f
                "Wave" -> 0.42f
                else -> 0.22f
            }
            glyphCanvas?.zoneLevels = zoneLevels
            mainHandler.postDelayed(this, 120L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadMapping()
        buildShell()
        probeRoot()
    }

    override fun onPause() {
        super.onPause()
        stopEffect(clear = false)
        rawScanRunning = false
        calibrationRunning = false
        scanIndex = -1
        mainHandler.removeCallbacks(rawScanTick)
        calibrationTitle?.text = "CALIBRATION PAUSED"
        calibrationInfo?.text = "Scanning stopped and Glyph outputs cleared while app is in the background."
        if (root.isReady) {
            root.allOff()
            zoneLevels.fill(0)
            channelLevels.fill(0)
            glyphCanvas?.zoneLevels = zoneLevels
        }
    }

    override fun onDestroy() {
        stopEffect(clear = false)
        if (root.isReady && !isChangingConfigurations) root.allOff()
        root.shutdown()
        super.onDestroy()
    }

    private fun buildShell() {
        rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(C_BG)
            setPadding(dp(16), dp(12), dp(16), dp(8))
        }
        setContentView(rootLayout)
        render()
    }

    private fun render() {
        rootLayout.removeAllViews()
        rootLayout.addView(header(), LinearLayout.LayoutParams(-1, -2))
        rootLayout.addView(tabBar(), LinearLayout.LayoutParams(-1, dp(48)))
        val scroll = ScrollView(this).apply {
            clipToPadding = false
            isFillViewport = false
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(12), 0, dp(28))
        }
        scroll.addView(content)
        rootLayout.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        glyphCanvas = null
        calibrationCanvas = null
        channelGrid = null
        when (currentTab) {
            Tab.PAINT -> renderPaint()
            Tab.CHANNELS -> renderChannels()
            Tab.CALIBRATE -> renderCalibration()
            Tab.EFFECTS -> renderEffects()
        }
        updateStatusText()
    }

    private fun header(): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(12))
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "GLYPH STUDIO"
            textSize = 22f
            letterSpacing = 0.08f
            setTextColor(C_TEXT)
            typeface = android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.BOLD)
        }
        top.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(actionButton("ROOT ↻", primary = false) { probeRoot() }, LinearLayout.LayoutParams(-2, dp(38)))
        box.addView(top)
        statusText = TextView(this).apply {
            textSize = 12f
            setTextColor(C_MUTED)
            setPadding(0, dp(5), 0, 0)
        }
        box.addView(statusText)
        return box
    }

    private fun tabBar(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(C_PANEL, 16)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        val tabs = listOf(
            Tab.PAINT to "PAINT",
            Tab.CHANNELS to "CHANNELS",
            Tab.CALIBRATE to "MAP",
            Tab.EFFECTS to "FX"
        )
        tabs.forEach { (tab, label) ->
            val b = actionButton(label, primary = currentTab == tab) {
                stopRawScan()
                if (currentTab != tab) {
                    if (currentTab == Tab.CALIBRATE && calibrationRunning) finishCalibration()
                    stopEffect()
                    currentTab = tab
                    render()
                }
            }
            row.addView(b, LinearLayout.LayoutParams(0, -1, 1f).apply { marginEnd = dp(3) })
        }
        return row
    }

    private fun renderPaint() {
        content.addView(sectionTitle("DRAW ON YOUR GLYPH"))
        content.addView(bodyText("Tap a zone to light it. Drag your finger across the diagram to paint a pattern. Calibrate first so each drawn zone knows which raw hardware channels to drive."))
        val canvas = GlyphCanvasView(this).apply {
            zoneLevels = this@MainActivity.zoneLevels
            mappedZones = hardwareToZone.values.toSet()
            layoutParams = LinearLayout.LayoutParams(-1, dp(490)).apply { topMargin = dp(10) }
            onZoneTouched = { index -> paintZone(index) }
        }
        glyphCanvas = canvas
        content.addView(canvas)
        content.addView(spacer(10))
        val toolRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        toolRow.addView(actionButton("PAINT", tool == Tool.PAINT) { tool = Tool.PAINT; render() }, weightedButton())
        toolRow.addView(actionButton("TAP TOGGLE", tool == Tool.TOGGLE) { tool = Tool.TOGGLE; render() }, weightedButton())
        toolRow.addView(actionButton("ERASE", tool == Tool.ERASE) { tool = Tool.ERASE; render() }, weightedButton())
        content.addView(toolRow)
        brushText = bodyText("Brush brightness · $brushBrightness / ${root.maxBrightness}")
        brushText.setPadding(0, dp(14), 0, 0)
        content.addView(brushText)
        val seek = SeekBar(this).apply {
            max = root.maxBrightness.coerceAtLeast(1)
            progress = brushBrightness.coerceAtMost(max)
            setOnSeekBarChangeListener(simpleSeek { value ->
                brushBrightness = value.coerceAtLeast(1)
                brushText.text = "Brush brightness · $brushBrightness / ${root.maxBrightness}"
            })
        }
        content.addView(seek)
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        controls.addView(actionButton("FILL MAPPED", true) { fillMapped() }, weightedButton())
        controls.addView(actionButton("CLEAR", false) { clearMapped() }, weightedButton())
        content.addView(controls)
        val presets = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        presets.addView(actionButton("SAVE SNAPSHOT", false) { saveSnapshot() }, weightedButton())
        presets.addView(actionButton("LOAD SNAPSHOT", false) { loadSnapshot() }, weightedButton())
        content.addView(presets)
        content.addView(noteCard("No mapping yet?", "Open MAP and scan the raw channels. When one lights on the back of your phone, tap the matching part of this diagram. You can also control every raw channel directly in CHANNELS."))
    }

    private fun renderChannels() {
        content.addView(sectionTitle("RAW HARDWARE CHANNELS"))
        content.addView(bodyText("Direct AW210xx access. The reference Phone (1) test covers indices 0–33. Tap a tile to toggle it, or select it and use the brightness slider."))
        channelTitle = bodyText("Selected channel · #${selectedChannel.toString().padStart(2, '0')} · ${channelLevels[selectedChannel]}")
        channelTitle?.setPadding(0, dp(14), 0, dp(4))
        content.addView(channelTitle)
        val seek = SeekBar(this).apply {
            max = root.maxBrightness.coerceAtLeast(1)
            progress = channelLevels[selectedChannel]
            setOnSeekBarChangeListener(simpleSeek { value -> setChannel(selectedChannel, value, false) })
        }
        channelSeekBar = seek
        content.addView(seek)
        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        quick.addView(actionButton("SET SELECTED", true) { setChannel(selectedChannel, brushBrightness, true) }, weightedButton())
        quick.addView(actionButton("CHANNEL OFF", false) { setChannel(selectedChannel, 0, true) }, weightedButton())
        content.addView(quick)
        val scanRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        scanRow.addView(actionButton(if (rawScanRunning) "STOP SCAN" else "SCAN 0–33", false) {
            if (rawScanRunning) stopRawScan() else startRawScan()
        }, weightedButton())
        scanRow.addView(actionButton("ALL OFF", false) { allOff() }, weightedButton())
        content.addView(scanRow)
        content.addView(sectionTitle("CHANNEL GRID"))
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        channelGrid = grid
        content.addView(grid)
        updateChannelGrid()
        content.addView(noteCard("Why raw channels?", "These are low-level AW210xx indices, not the same numbering as the 15 logical zones in Nothing's Glyph SDK. Use MAP to relate them to the visual editor."))
    }

    private fun renderCalibration() {
        content.addView(sectionTitle("HARDWARE MAPPING WIZARD"))
        content.addView(bodyText("The app lights one raw channel at a time. Look at the back of the phone, then tap the matching Glyph zone below. If nothing lights, skip that channel. Multiple raw channels may be assigned to one logical zone."))
        calibrationTitle = sectionTitle("READY · CHANNEL NOT SCANNING")
        content.addView(calibrationTitle)
        calibrationInfo = bodyText("34 raw indices · 15 logical zones · ${hardwareToZone.size} mappings saved")
        content.addView(calibrationInfo)
        val canvas = GlyphCanvasView(this).apply {
            selectionOnly = true
            mappedZones = hardwareToZone.values.toSet()
            zoneLevels = zoneLevelsForMapping()
            layoutParams = LinearLayout.LayoutParams(-1, dp(455)).apply { topMargin = dp(8) }
            onZoneTouched = { zone -> assignCurrentChannel(zone) }
        }
        calibrationCanvas = canvas
        content.addView(canvas)
        content.addView(bodyText("Small sections such as the eight USB-line slices can be easier to assign from this list:"))
        val zoneNames = GlyphZones.all.sortedBy { it.index }.map { "${it.name} · ${it.group}" }
        calibrationZoneSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, zoneNames)
            setSelection(selectedCalibrationZone.coerceIn(0, zoneNames.lastIndex))
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                    selectedCalibrationZone = GlyphZones.all.sortedBy { it.index }.getOrNull(position)?.index ?: 0
                }
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
            }
        }
        content.addView(calibrationZoneSpinner, LinearLayout.LayoutParams(-1, dp(48)))
        content.addView(actionButton("ASSIGN CHOSEN ZONE TO CURRENT LED", false) {
            assignCurrentChannel(selectedCalibrationZone)
        }, LinearLayout.LayoutParams(-1, dp(44)))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(actionButton("${if (calibrationRunning) "SCANNING" else "START"}", true) {
            if (calibrationRunning) finishCalibration() else startCalibration()
        }, weightedButton())
        row.addView(actionButton("SKIP", false) { skipCalibrationChannel() }, weightedButton())
        row.addView(actionButton("FINISH", false) { finishCalibration() }, weightedButton())
        content.addView(row)
        content.addView(actionButton("CLEAR ALL MAPPINGS", false) { clearMapping() }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(6) })
        content.addView(noteCard("Calibration tip", "For each channel, only one raw index is being driven at a time. Assign the illuminated physical section to A1, B1, C1–C4, D1_1–D1_8 or E1. The diagram is a logical guide; your mapping makes it accurate for your kernel."))
    }

    private fun renderEffects() {
        content.addView(sectionTitle("LIVE ANIMATIONS"))
        content.addView(bodyText("Animations run only while Glyph Studio is in the foreground. They stop and clear the Glyph outputs when you leave the app."))
        content.addView(noteCard("Calibration required", "Effects operate on the logical zones you've mapped. Current mapped zones: ${hardwareToZone.values.toSet().size} / 15."))
        val names = listOf("Breathe", "Chase", "Wave", "Pulse")
        names.forEach { name ->
            content.addView(actionButton(name.uppercase(), effectName == name) { startEffect(name) }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(7) })
        }
        content.addView(actionButton("STOP + ALL OFF", false) { stopEffect(); allOff() }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(12) })
        content.addView(sectionTitle("ANIMATION PEAK BRIGHTNESS"))
        val peakText = bodyText("Peak · $brushBrightness / ${root.maxBrightness}")
        content.addView(peakText)
        content.addView(SeekBar(this).apply {
            max = root.maxBrightness.coerceAtLeast(1)
            progress = brushBrightness.coerceAtMost(max)
            setOnSeekBarChangeListener(simpleSeek { value ->
                brushBrightness = value.coerceAtLeast(1)
                peakText.text = "Peak · $brushBrightness / ${root.maxBrightness}"
            })
        })
    }

    private fun paintZone(zone: Int) {
        val next = when (tool) {
            Tool.PAINT -> brushBrightness
            Tool.ERASE -> 0
            Tool.TOGGLE -> if (zoneLevels[zone] > 0) 0 else brushBrightness
        }
        zoneLevels[zone] = next
        glyphCanvas?.selectedZone = zone
        glyphCanvas?.zoneLevels = zoneLevels
        val channels = hardwareToZone.filterValues { it == zone }.keys
        if (channels.isEmpty()) {
            if (tool != Tool.ERASE) toast("Zone ${GlyphZones.byIndex[zone]?.name} has no calibrated raw channel")
            return
        }
        root.writeBatch(channels.associateWith { next })
        channels.forEach { channelLevels[it] = next }
    }

    private fun fillMapped() {
        if (hardwareToZone.isEmpty()) {
            toast("Calibrate raw channels first")
            return
        }
        hardwareToZone.values.distinct().forEach { zoneLevels[it] = brushBrightness }
        root.writeBatch(hardwareToZone.keys.associateWith { brushBrightness })
        glyphCanvas?.zoneLevels = zoneLevels
    }

    private fun clearMapped() {
        hardwareToZone.values.distinct().forEach { zoneLevels[it] = 0 }
        root.writeBatch(hardwareToZone.keys.associateWith { 0 })
        glyphCanvas?.zoneLevels = zoneLevels
    }

    private fun setChannel(index: Int, value: Int, force: Boolean) {
        if (index !in channelLevels.indices) return
        channelLevels[index] = value.coerceIn(0, root.maxBrightness)
        if (force || value != 0 || channelLevels[index] == 0) {
            root.writeBatch(mapOf(index to channelLevels[index]))
        }
        channelTitle?.text = "Selected channel · #${index.toString().padStart(2, '0')} · ${channelLevels[index]}"
        channelSeekBar?.let { if (it.progress != channelLevels[index]) it.progress = channelLevels[index] }
        updateChannelGrid()
    }

    private fun updateChannelGrid() {
        val grid = channelGrid ?: return
        grid.removeAllViews()
        var index = 0
        while (index < RootSysfs.CHANNEL_COUNT) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            repeat(4) {
                val channel = index
                if (channel < RootSysfs.CHANNEL_COUNT) {
                    val label = "${channel.toString().padStart(2, '0')}\n${if (channelLevels[channel] == 0) "OFF" else channelLevels[channel]}"
                    val b = actionButton(label, channel == selectedChannel || channelLevels[channel] > 0) {
                        selectedChannel = channel
                        channelSeekBar?.progress = channelLevels[channel]
                        val now = if (channelLevels[channel] > 0) 0 else brushBrightness
                        setChannel(channel, now, true)
                    }.apply { textSize = 11f }
                    row.addView(b, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginEnd = dp(5); bottomMargin = dp(5) })
                } else {
                    row.addView(View(this), LinearLayout.LayoutParams(0, dp(50), 1f))
                }
                index++
            }
            grid.addView(row)
        }
        channelTitle?.text = "Selected channel · #${selectedChannel.toString().padStart(2, '0')} · ${channelLevels[selectedChannel]}"
    }

    private fun startRawScan() {
        if (!root.isReady) {
            toast("Grant root access first")
            probeRoot()
            return
        }
        stopEffect()
        rawScanRunning = true
        scanIndex = 0
        mainHandler.removeCallbacks(rawScanTick)
        rawScanTick.run()
    }

    private fun stopRawScan() {
        if (!rawScanRunning) return
        rawScanRunning = false
        mainHandler.removeCallbacks(rawScanTick)
        scanIndex = -1
        root.allOff()
        channelLevels.fill(0)
        updateChannelGrid()
    }

    private fun startCalibration() {
        if (!root.isReady) {
            toast("Grant root access first")
            probeRoot()
            return
        }
        stopEffect()
        stopRawScan()
        calibrationRunning = true
        scanIndex = 0
        showCalibrationChannel()
    }

    private fun showCalibrationChannel() {
        if (!calibrationRunning || scanIndex !in 0 until RootSysfs.CHANNEL_COUNT) {
            finishCalibration()
            return
        }
        val output = (0 until RootSysfs.CHANNEL_COUNT).associateWith { if (it == scanIndex) 750 else 0 }
        root.writeBatch(output)
        calibrationTitle?.text = "CHANNEL ${scanIndex.toString().padStart(2, '0')} IS LIT"
        calibrationInfo?.text = "${scanIndex + 1} / ${RootSysfs.CHANNEL_COUNT} · ${hardwareToZone.size} mappings saved · Tap the matching Glyph zone"
        calibrationCanvas?.selectedZone = -1
        calibrationCanvas?.zoneLevels = zoneLevelsForMapping()
    }

    private fun assignCurrentChannel(zone: Int) {
        if (!calibrationRunning || scanIndex !in 0 until RootSysfs.CHANNEL_COUNT) {
            toast("Press START to begin calibration")
            return
        }
        hardwareToZone[scanIndex] = zone
        saveMapping()
        calibrationCanvas?.selectedZone = zone
        calibrationCanvas?.mappedZones = hardwareToZone.values.toSet()
        val assigned = scanIndex
        scanIndex++
        if (scanIndex >= RootSysfs.CHANNEL_COUNT) {
            finishCalibration()
            toast("Calibration complete · mapped $assigned and previous channels")
        } else {
            showCalibrationChannel()
        }
    }

    private fun skipCalibrationChannel() {
        if (!calibrationRunning) {
            toast("Start calibration first")
            return
        }
        root.writeBatch(mapOf(scanIndex to 0))
        scanIndex++
        if (scanIndex >= RootSysfs.CHANNEL_COUNT) finishCalibration() else showCalibrationChannel()
    }

    private fun finishCalibration() {
        calibrationRunning = false
        scanIndex = -1
        root.allOff()
        channelLevels.fill(0)
        zoneLevels.fill(0)
        saveMapping()
        calibrationTitle?.text = "CALIBRATION READY"
        calibrationInfo?.text = "${hardwareToZone.size} raw channels mapped · ${hardwareToZone.values.toSet().size} logical zones assigned"
        calibrationCanvas?.mappedZones = hardwareToZone.values.toSet()
        calibrationCanvas?.zoneLevels = zoneLevelsForMapping()
    }

    private fun clearMapping() {
        finishCalibration()
        hardwareToZone.clear()
        saveMapping()
        calibrationCanvas?.mappedZones = emptySet()
        calibrationInfo?.text = "Mappings cleared · scan the raw outputs again"
        toast("Mapping cleared")
    }

    private fun startEffect(name: String) {
        if (!root.isReady) {
            toast("Grant root access first")
            return
        }
        if (hardwareToZone.isEmpty()) {
            toast("Calibrate the raw channels first")
            return
        }
        stopEffect(clear = false)
        effectName = name
        effectPhase = 0f
        render()
        mainHandler.post(effectTick)
    }

    private fun stopEffect(clear: Boolean = true) {
        mainHandler.removeCallbacks(effectTick)
        effectName = null
        if (clear && root.isReady) root.allOff()
    }

    private fun allOff() {
        stopEffect(clear = false)
        channelLevels.fill(0)
        zoneLevels.fill(0)
        root.allOff()
        glyphCanvas?.zoneLevels = zoneLevels
        updateChannelGrid()
        toast("All raw channels switched off")
    }

    private fun buildHardwareFrame(levels: IntArray): Map<Int, Int> {
        val frame = linkedMapOf<Int, Int>()
        hardwareToZone.forEach { (channel, zone) -> frame[channel] = levels.getOrElse(zone) { 0 } }
        return frame
    }

    private fun zoneLevelsForMapping(): IntArray {
        val levels = IntArray(15)
        hardwareToZone.values.distinct().forEach { zone ->
            levels[zone] = hardwareToZone.filterValues { it == zone }.keys.maxOfOrNull { channelLevels[it] } ?: 0
        }
        return levels
    }

    private fun saveSnapshot() {
        prefs.edit().putString("snapshot", zoneLevels.joinToString(",")).apply()
        toast("Snapshot saved")
    }

    private fun loadSnapshot() {
        val raw = prefs.getString("snapshot", null) ?: run {
            toast("No saved snapshot")
            return
        }
        val values = raw.split(",").mapNotNull { it.toIntOrNull() }
        if (values.size != 15) {
            toast("Saved snapshot is invalid")
            return
        }
        values.forEachIndexed { i, value -> zoneLevels[i] = value.coerceIn(0, root.maxBrightness) }
        root.writeBatch(buildHardwareFrame(zoneLevels))
        glyphCanvas?.zoneLevels = zoneLevels
        toast("Snapshot loaded")
    }

    private fun saveMapping() {
        val serialized = hardwareToZone.toSortedMap().entries.joinToString(",") { "${it.key}:${it.value}" }
        prefs.edit().putString("mapping", serialized).apply()
    }

    private fun loadMapping() {
        hardwareToZone.clear()
        val serialized = prefs.getString("mapping", "") ?: ""
        serialized.split(",").forEach { entry ->
            val pair = entry.split(":")
            val channel = pair.getOrNull(0)?.toIntOrNull()
            val zone = pair.getOrNull(1)?.toIntOrNull()
            if (channel != null && zone != null && channel in 0 until RootSysfs.CHANNEL_COUNT && zone in 0..14) {
                hardwareToZone[channel] = zone
            }
        }
    }

    private fun probeRoot() {
        if (this::statusText.isInitialized) statusText.text = "Checking root and AW210xx interface…"
        root.probe { ready, message ->
            mainHandler.post {
                if (this::statusText.isInitialized) statusText.text = if (ready) "● $message" else "○ $message"
                if (ready) {
                    if (brushBrightness > root.maxBrightness) brushBrightness = root.maxBrightness
                }
            }
        }
    }

    private fun updateStatusText() {
        if (!this::statusText.isInitialized) return
        statusText.text = if (root.isReady) "● Root ready · ${hardwareToZone.size} raw mappings" else "○ Root not connected · tap ROOT ↻"
    }

    private fun sectionTitle(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 13f
        letterSpacing = 0.08f
        typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
        setTextColor(C_MUTED)
        setPadding(0, dp(14), 0, dp(7))
    }

    private fun bodyText(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(C_MUTED)
        setLineSpacing(dp(2).toFloat(), 1f)
    }

    private fun noteCard(title: String, message: String): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(C_PANEL, 16)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        val heading = TextView(this).apply {
            text = title.uppercase()
            textSize = 11f
            letterSpacing = 0.06f
            setTextColor(C_TEXT)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val detail = bodyText(message).apply { setPadding(0, dp(6), 0, 0) }
        card.addView(heading)
        card.addView(detail)
        card.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) }
        return card
    }

    private fun actionButton(text: String, primary: Boolean, onClick: () -> Unit): Button {
        return Button(this).apply {
            this.text = text
            isAllCaps = false
            textSize = 11f
            letterSpacing = 0.03f
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
            setTextColor(if (primary) C_BG else C_TEXT)
            background = rounded(if (primary) C_ACCENT else C_BUTTON, 12)
            minHeight = dp(40)
            minimumHeight = dp(40)
            minWidth = 0
            minimumWidth = 0
            setPadding(dp(6), dp(4), dp(6), dp(4))
            setOnClickListener { onClick() }
        }
    }

    private fun simpleSeek(onProgress: (Int) -> Unit): SeekBar.OnSeekBarChangeListener = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
            if (fromUser) onProgress(progress)
        }
        override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
        override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
    }

    private fun weightedButton(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(5) }
    private fun spacer(height: Int): View = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }
    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    companion object {
        private val C_BG = Color.rgb(11, 13, 15)
        private val C_PANEL = Color.rgb(24, 28, 32)
        private val C_BUTTON = Color.rgb(40, 46, 51)
        private val C_ACCENT = Color.rgb(239, 70, 77)
        private val C_TEXT = Color.rgb(237, 242, 244)
        private val C_MUTED = Color.rgb(151, 161, 166)
    }
}
