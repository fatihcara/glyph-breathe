package com.spacegoat.glyphstudio

import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** Root-only bridge to the Phone (1) AW210xx sysfs node.
 * single_led_br is write-only on some kernels, so this class never tries to read it.
 */
class RootSysfs {
    companion object {
        const val CHANNEL_COUNT = 34 // The Phone (1) reference sysfs test iterates 0..33.
        private const val NODE = "/sys/class/leds/aw210xx_led/single_led_br"
        private const val MAX_NODE = "/sys/class/leds/aw210xx_led/max_brightness"
    }

    private val worker: ExecutorService = Executors.newSingleThreadExecutor()
    @Volatile var maxBrightness: Int = 4095
        private set
    @Volatile var isReady: Boolean = false
        private set

    fun probe(callback: (Boolean, String) -> Unit) {
        worker.execute {
            val result = runRoot("id -u; cat '$MAX_NODE'; test -e '$NODE' && echo GLYPH_NODE_OK")
            val lines = result.output.lines().map { it.trim() }
            val rootLine = lines.firstOrNull { it == "0" }
            val maxLine = lines.firstOrNull { it.toIntOrNull() != null }
            val max = maxLine?.toIntOrNull()?.takeIf { it > 0 } ?: 4095
            val okay = result.exitCode == 0 && rootLine != null && lines.any { it == "GLYPH_NODE_OK" }
            maxBrightness = max
            isReady = okay
            val message = when {
                okay -> "Root ready · max brightness $max"
                rootLine == null -> "Root access unavailable · approve Glyph Studio in Magisk/Kitsune"
                else -> "Root granted, but the AW210xx sysfs node was not found"
            }
            callback(okay, message)
        }
    }

    /** Writes many outputs in one root-shell process. Values are clamped before reaching the shell. */
    fun writeBatch(values: Map<Int, Int>, callback: ((Boolean, String) -> Unit)? = null) {
        if (values.isEmpty()) return
        val safe = values.entries
            .filter { it.key in 0 until CHANNEL_COUNT }
            .associate { it.key to it.value.coerceIn(0, maxBrightness) }
        if (safe.isEmpty()) return

        worker.execute {
            val script = buildString {
                append("failed=0\n")
                safe.toSortedMap().forEach { (index, brightness) ->
                    append("printf '%s\\n' '")
                    append(index)
                    append(' ')
                    append(brightness)
                    append("' > '")
                    append(NODE)
                    append("' || failed=1\n")
                }
                append("if [ \"\$failed\" -eq 0 ]; then echo GLYPH_WRITE_OK; else echo GLYPH_WRITE_PARTIAL; exit 42; fi")
            }
            val result = runRoot(script)
            val success = result.exitCode == 0 && result.output.contains("GLYPH_WRITE_OK")
            callback?.invoke(success, if (success) "Glyph outputs updated" else "Sysfs write failed: ${result.output.take(160)}")
        }
    }

    fun allOff(callback: ((Boolean, String) -> Unit)? = null) {
        writeBatch((0 until CHANNEL_COUNT).associateWith { 0 }, callback)
    }

    fun shutdown() {
        worker.shutdown()
    }

    private data class RootResult(val exitCode: Int, val output: String)

    private fun runRoot(command: String): RootResult {
        return try {
            val process = ProcessBuilder("su", "-c", command)
                .redirectErrorStream(true)
                .start()
            val output = process.inputStream.bufferedReader().use { it.readText() }
            val code = process.waitFor()
            RootResult(code, output)
        } catch (e: Exception) {
            RootResult(127, e.message ?: e.javaClass.simpleName)
        }
    }
}
